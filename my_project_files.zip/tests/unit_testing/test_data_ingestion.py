import pytest
from my_library.data_ingestion import fetch_housing_data, load_housing_data


def test_fetch_housing_data():
    # Add a test for checking if the housing data is fetched and extracted correctly
    # You can use a temporary directory for testing and delete it afterward.
    pass


def test_load_housing_data():
    # Add a test for checking if the housing data is loaded correctly
    # You can create a small sample CSV file for testing purposes.
    pass
