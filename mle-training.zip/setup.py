# setup.py

from setuptools import find_packages, setup

setup(
    name="mle-training-rishu",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        # List your package dependencies here
    ],
    entry_points={
        "console_scripts": [
            # Define any command-line scripts here
        ],
    },
)
